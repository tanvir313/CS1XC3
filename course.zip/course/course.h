/**
 * @file course.h
 * @author Tanvir Singh
 * @date April 11th, 2022
 * @brief The course library contains functions for enrolling students into courses, printing 
 *        course info, returning top and passing students.
*/

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course type stores a course with fields name, code, array of students and number of total students.
 * 
 */

typedef struct _course 
{
  char name[100];  /**< the name of the course */
  char code[10];  /**< the course code */
  Student *students;  /**< the array of students */
  int total_students;  /**< number of total students in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


